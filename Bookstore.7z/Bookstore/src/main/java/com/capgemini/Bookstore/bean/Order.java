package com.capgemini.Bookstore.bean;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "orders")
public class Order {
	
	@Id
	@NotNull
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ord_Id",length=10)
	private int orderId;
	@NotNull
	private int total;
	@NotNull
	private String orderStatus;
	private String paymentMethod;
	@ManyToOne
	@JoinColumn(name="cust_Id")
	private Customer custmerId; 
	@OneToMany(cascade= CascadeType.ALL)
	private Set<OrderDetails> ordersDeails =  new HashSet<OrderDetails>();
	

}
