package com.capgemini.Bookstore.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "admindetail")
public class Admin {
	
	@Id
	@NotNull
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="admin_ID")
	private int adminId;
	@NotNull
	@Column(name="fullName")
	private String adminFullName;
	@NotNull
	@Column(name="emailID")
	private String adminEmailId;
	@NotNull
	@Column(name="password")
	private String password;
	public Admin(int adminId, String adminFullName, String adminEmailId, String password) {
		super();
		this.adminId = adminId;
		this.adminFullName = adminFullName;
		this.adminEmailId = adminEmailId;
		this.password = password;
	}
	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getAdminId() {
		return adminId;
	}
	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}
	public String getAdminFullName() {
		return adminFullName;
	}
	public void setAdminFullName(String adminFullName) {
		this.adminFullName = adminFullName;
	}
	public String getAdminEmailId() {
		return adminEmailId;
	}
	public void setAdminEmailId(String adminEmailId) {
		this.adminEmailId = adminEmailId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "Admin [adminId=" + adminId + ", adminFullName=" + adminFullName + ", adminEmailId=" + adminEmailId
				+ ", password=" + password + "]";
	}

	

}
