package com.capgemini.Bookstore.bean;

import java.util.ArrayList;
import java.util.List;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "customerdetail")
public class Customer {
	
	@Id
	@NotNull
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="cust_Id",length=10)
	private int customerId;
	@NotNull
	private String customerFullName;
	@NotNull
	private String customerEmail;
	@NotNull
	private String customerPhoneNumber;
	@NotNull
	private String customerAddress;
	@NotNull
	private String customerZipCode;
	private String customerCity;
	private String country;
	@OneToMany(cascade= CascadeType.ALL)
	private List<Order> orders =  new ArrayList<Order>();
	
	
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerFullName() {
		return customerFullName;
	}
	public void setCustomerFullName(String customerFullName) {
		this.customerFullName = customerFullName;
	}
	public String getCustomerEmail() {
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	public String getCustomerPhoneNumber() {
		return customerPhoneNumber;
	}
	public void setCustomerPhoneNumber(String customerPhoneNumber) {
		this.customerPhoneNumber = customerPhoneNumber;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	public String getCustomerZipCode() {
		return customerZipCode;
	}
	public void setCustomerZipCode(String customerZipCode) {
		this.customerZipCode = customerZipCode;
	}
	public String getCustomerCity() {
		return customerCity;
	}
	public void setCustomerCity(String customerCity) {
		this.customerCity = customerCity;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerFullName=" + customerFullName + ", customerEmail="
				+ customerEmail + ", customerPhoneNumber=" + customerPhoneNumber + ", customerAddress="
				+ customerAddress + ", customerZipCode=" + customerZipCode + ", customerCity=" + customerCity
				+ ", country=" + country + "]";
	}
	
	
	
	
	
	
	

}
