package com.capgemini.Bookstore.Repository;

import java.util.List;

import com.capgemini.Bookstore.bean.Book;
import com.capgemini.Bookstore.bean.BookReview;

public interface BookRepo {
	
	public List<Book> specificCategory();
	public List<Book> mostRecentPublishedBook();
	public List<Book> viewBestSellingBook();
	public List<Book> mostFavouredBook();
	public List<BookReview> viewAllCustomerReview();
	

}
