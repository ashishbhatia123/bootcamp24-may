package com.capgemini.Bookstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.Bookstore.Repository.BookRepo;
import com.capgemini.Bookstore.Repository.LoginRepo;

@Service
public class LoginServiceImpl implements LoginService {

	
	@Autowired
	LoginRepo loginrp;

	@Override
	public boolean addAdmin() {
		
		return loginrp.addAdmin() ;
	}

	@Override
	public boolean addCustomer() {
		
		return loginrp.addCustomer();
	}
	
}
