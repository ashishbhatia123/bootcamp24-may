package com.capgemini.Bookstore.Repository;

import com.capgemini.Bookstore.bean.Cart;

public interface CartRepo {
	
	public Cart removeCart();
	public Cart addBookToCart();
	public Cart updateQuantity();
	
	

}
