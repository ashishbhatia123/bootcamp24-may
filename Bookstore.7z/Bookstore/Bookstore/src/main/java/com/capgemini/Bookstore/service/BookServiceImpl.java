package com.capgemini.Bookstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.Bookstore.Repository.AdminRepo;
import com.capgemini.Bookstore.Repository.BookRepo;
import com.capgemini.Bookstore.bean.Book;
import com.capgemini.Bookstore.bean.BookReview;

@Service
public class BookServiceImpl implements BookService {

	
	@Autowired
	BookRepo bookrp;
	
	@Override
	public List<Book> specificCategory() {
	
		return bookrp.specificCategory();
	}

	@Override
	public List<Book> mostRecentPublishedBook() {
		
		return bookrp.mostRecentPublishedBook();
	}

	@Override
	public List<Book> viewBestSellingBook() {
		
		return bookrp.viewBestSellingBook();
	}

	@Override
	public List<Book> mostFavouredBook() {
		
		return bookrp.mostFavouredBook();
	}

	@Override
	public List<BookReview> viewAllCustomerReview() {
		
		return bookrp.viewAllCustomerReview();
	}

}
