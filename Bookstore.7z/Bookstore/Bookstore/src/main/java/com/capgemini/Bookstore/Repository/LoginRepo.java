package com.capgemini.Bookstore.Repository;

public interface LoginRepo {
	
	public boolean addAdmin();
	public boolean addCustomer();
	

}
